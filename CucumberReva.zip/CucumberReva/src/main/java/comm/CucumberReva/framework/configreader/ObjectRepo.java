package comm.CucumberReva.framework.configreader;

public class ObjectRepo {

	public static ConfigReader reader;
}
