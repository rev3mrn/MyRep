
package comm.CucumberReva.framework.configuration.browser;
/**
 * 
 * @author bsingh5
 *
 */
public enum BrowserType {
	Firefox,
	Iexplorer,
	HtmlUnitDriver,
	Chrome
}
